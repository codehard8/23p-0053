#include<stdio.h>

int sequence(int digit){
	        int b=0; // represent lenght 
	        while(digit != 1){ //loop will run until digit is equal to one by following mathimitica
			
	    	   if(digit%2==0){ //when digit is even this equaion follows
			      digit = digit/2;
	    	    }
	    	   else if(digit % 2==1){ //when digit is odd 
			      digit = digit*3+1;
	    	    }
	    	    
	    	   b++;
	    	   
	    	}
		
	//	printf(" %d", b);
	
	return ++b; /* return length to main of passed value*/
}

int main(){
	
	int digit, Longest_strak_num, max=0, a; /* a is supporting variable to counter negative values */
	printf("Enter A Num to apply collatz sequence:");
	scanf(" %d", &digit);
	if(digit<0)  a=-(digit);  /* line 28,29 for counting negative values to use only one loop*/
	else a=digit;
	for(int i=a; i>0; i--){
		
	 int len =  sequence(i); /* passing each value till zero from user input digit to find lenght of each digit*/
	 if(len>max){                           
	 	max=len;               /*if maximum lenght is less then return lenght so longest streak digit be equal to that value of i passed to ftn*/
	 	Longest_strak_num=i;   
	 }
	 
    }
    if(digit<0) printf("\nthe Longest streak is on num -%d\n", Longest_strak_num); /*if digit is -ve then - sign is neccessarry as i make it positve above for efficency */
    else        printf("\nthe Longest streak is on num %d\n", Longest_strak_num);
    
                printf("the Maximum lenth is %d", max);
    
	return 0;
}