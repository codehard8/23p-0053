#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define HAND_SIZE 5 // Maximum number of cards in a hand

// Function to parse card ranks and suits
void parseCard(char card[], char *rank, char *suit) {
    *rank = card[0]; // Get the rank from the card string
    *suit = card[1]; // Get the suit from the card string
}

// Function to compare two cards by rank
int compareCards(char rank1, char rank2) {
    // Compare ranks of two cards
    if (rank1 == rank2) // If ranks are equal
        return 0; // Return 0 for equal ranks
    else if (rank1 == 'A') // Ace is highest
        return 1; // Return 1 if rank1 is higher (Ace)
    else if (rank2 == 'A') // Ace is highest
        return -1; // Return -1 if rank2 is higher (Ace)
    else if (rank1 == 'K') // King is higher than others except Ace
        return 1; // Return 1 if rank1 is higher (King)
    else if (rank2 == 'K') // King is higher than others except Ace
        return -1; // Return -1 if rank2 is higher (King)
    else if (rank1 == 'Q') // Queen is higher than others except Ace and King
        return 1; // Return 1 if rank1 is higher (Queen)
    else if (rank2 == 'Q') // Queen is higher than others except Ace and King
        return -1; // Return -1 if rank2 is higher (Queen)
    else if (rank1 == 'J') // Jack is higher than others except Ace, King, and Queen
        return 1; // Return 1 if rank1 is higher (Jack)
    else if (rank2 == 'J') // Jack is higher than others except Ace, King, and Queen
        return -1; // Return -1 if rank2 is higher (Jack)
    else if (rank1 == 'T') // Ten is higher than numerical ranks but lower than Jack, Queen, King, Ace
        return 1; // Return 1 if rank1 is higher (Ten)
    else if (rank2 == 'T') // Ten is higher than numerical ranks but lower than Jack, Queen, King, Ace
        return -1; // Return -1 if rank2 is higher (Ten)
    else // Numerical ranks (2-9)
        return (rank1 - rank2); // Return the difference in ASCII values for comparison
}

// Function to determine if a hand is a flush
int isFlush(char hand[]) {
    char suit = hand[1]; // Get the suit of the first card
    int i = 3; // Start index for the next card in the hand
    do {
        if (hand[i + 1] != suit) // If the suit of the next card is different
            return 0; // Not a flush, return 0
        i += 3; // Move to the next card in the hand
    } while (i < HAND_SIZE * 3); // Continue until all cards in the hand are checked
    return 1; // All cards have the same suit, it's a flush
}

// Function to determine if a hand is a straight
int isStraight(char ranks[]) {
    int i = 0; // Start index for comparing ranks
    do {
        if (ranks[i] != ranks[i + 1] - 1) // If ranks are not consecutive
            return 0; // Not a straight, return 0
        i++; // Move to the next rank in the hand
    } while (i < HAND_SIZE - 1); // Continue until all ranks in the hand are checked
    return 1; // All ranks are consecutive, it's a straight
}

// Function to determine the winning player for a set of poker hands
void determineWinner(char p1[], char p2[]) {
    int win_p1 = 0, win_p2 = 0; // Initialize counters for player 1 and player 2 wins
    char ranks[] = "23456789TJQKA"; // Possible ranks in a standard deck of cards
    int i = 0; // Index for iterating through the cards in the hand
    do {
        char r1, s1, r2, s2; // Variables to store rank and suit of each card for players 1 and 2
        parseCard(&p1[i * 3], &r1, &s1); // Parse the rank and suit of player 1's card
        parseCard(&p2[i * 3], &r2, &s2); // Parse the rank and suit of player 2's card

        int r1_idx = strchr(ranks, r1) - ranks; // Index of rank in ranks array for player 1
        int r2_idx = strchr(ranks, r2) - ranks; // Index of rank in ranks array for player 2
        // Compare ranks for straight and high card
        if (r1_idx != r2_idx) {
            if (r1_idx > r2_idx)
                win_p1++; // Increment player 1's win count
            else
                win_p2++; // Increment player 2's win count
        }
        i++;
    } while (i < HAND_SIZE); // Continue until all cards in the hand are checked

    // Determine the winner based on the win counts
    if (win_p1 > win_p2)
        printf("Player 1 wins\n");
    else if (win_p2 > win_p1)
        printf("Player 2 wins\n");
    else
        printf("It's a tie\n");
}

int main() {
    int num_hands; // Variable to store the number of hands provided by the user

    printf("How many lines of hands are you providing? ");
    scanf("%d", &num_hands); // Read the number of hands from the user
    getchar(); // Consume newline character after scanf

    if (num_hands > 0) { // Check if the number of hands is valid
        char input[256]; // Buffer to store user input
        
        printf("Enter hands of cards (each hand separated by a space):\n");
        for (int i = 0; i < num_hands; i++) {
            fgets(input, sizeof(input), stdin); // Read a line of input from the user
            input[strcspn(input, "\n")] = '\0'; // Remove newline character
            
            char *p1 = input; // Pointer to player 1's hand
            char *p2 = strchr(input, ' ') + 1; // Pointer to player 2's hand (after the space)

            printf("Hand %d: ", i + 1); // Print the hand number
            determineWinner(p1, p2); // Call function to determine the winner
        }
    } else {
        printf("Invalid number of hands.\n"); // Inform the user about invalid input
    }

    return 0; // Return 0 to indicate successful execution
}
