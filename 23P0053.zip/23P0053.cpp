//program to find maximum of four adjecent elements in a metrix
// the c-3 or r-3 are used in loops to avid unnaccessary no ghich didnot make a list of 4

/* generaly i used 1st loop for row or columns or diagonal then nested one for columns and the
 third nested one is for a list of four consective numbers to be producr*/
 
/* th third loop works like that if a row have elements 1 2 3 4 5 6 then list of four will be 1234,2345 and their product
 willbe find the rest agnore due to c-3 or r-3 etc which don't make list of four*/
 
// the n variable n=4 (k<n) or k<4  these are used in third nested loop to find product of four each time it iss limit 
// used int sum variable for product

#include <stdio.h>

int main()
{
    int r=6,c=6,mixAll=0, direction, mixR = 0, mixC=0, mixD1 =0,mixD2 =0, mixD3=0, mixD4 = 0;
    int arr[6][6]={{1,2,3,4,5,6},
	               {3, 6,7,12,34,67},
				   {7, 4,71, 76, 8,12},
				   {0, 4,4, 6, 8, 1}, 
				   {8,45,3, 7, 9, 0}, 
				   {4, 7,9, 12,45,67}
	};
   // This loops is finding maximum product in horizontal direction
    for (int i=0; i<r; i++){ // iterate through all rows 
        int k=0,n=4; 
        for(int j=1; j<=c-3; j++){ // atreated through possible 4 no list columns in a row repetdly
        	int sum=1;
            for(int m=k; m<n; m++){ // to find all posible list of four in horizonta eg a row 1 2 3 4 5 6 then list of for will be 1234,2345 the rest agnore due to c-3which don't make list of four
                sum*=arr[i][m];   
            }
            if(sum>mixR){
                	mixR=sum;
				}
           // printf("%d\n", sum);
            k++;
            n++;
        }
    }
       printf("maximum in rows direction is %d\n", mixR);
       if(mixR>mixAll){ 
           mixAll=mixR;
           direction=1;
       }
      // for virtical direction opposite of horizontal direction
     for (int i=0; i<c; i++){  /* this time we will atrate through column */
         int k=0,n=4;
        for(int j=1; j<=r-3; j++){ // through each row
        	int sum=1;
            for(int m=k; m<n; m++){  	/*column    so the list will be (1234),(2345)
			                              1
										  2
										  3
										  4
										  5*/
                sum*=arr[m][i];   
            }
            if(sum>mixC){
                	mixC=sum;
				}
           // printf("%d\n", sum);
            k++;
            n++;
        }
    }
       printf("maximum of column direction is %d\n", mixC);
        if(mixC>mixAll){ 
            mixAll=mixC;
            direction=2;
        }
        
        /* for find sum in diagonal in directin of left top to bottum right
       1**  for demonstration
       *1*
       **1
    */
      for (int i = 0; i < r - 3; i++) { /*the first loop will run until the all possible product be done like it is for how many times will the four elemnts product be done*/
        for (int j = 0; j < c - 3; j++) {
            int sum = 1;
            for (int k = 0; k < 4; k++) {
                sum *= arr[i + k][j + k]; // Sum  four adjacent numbers along the diagonal w
            }
            if (sum > mixD1) {
                mixD1 = sum; // Update max in dn direction Diagonal 1 if a larger sum is found
            }
        }
    }
    printf("maximum along  diagonal 1 is %d\n", mixD1);
     if(mixD1>mixAll){ 
         mixAll=mixD1;
         direction=3;
     }
    
    /* for find diagonal in directin of right top to bottum left 
       **1  for demonstration
       *1*
       1**
    */
    for (int i = 0; i < r - 3; i++) {
        for (int j = c - 1; j > c - 3; j--) {
            int sum = 1;
            for (int k = 0; k < 4; k++) {
                sum *= arr[i + k][j - k]; // Sum four adjacent numbers along the diagonal
            }
            if (sum > mixD2) {
                mixD2 = sum; // Update maxD2  if a larger sum is found in direction of diagonal 2
            }
        }
    }
    printf("maximum along  diagonal 2 is %d\n", mixD2);
    if(mixD2>mixAll){
         mixAll=mixD2;
        direction=3;
    }
    
    /* opposit of diagonal direction
    
    */
	 for (int i = r-1; i >= r - 3; i--) {
        for (int j = c-1; j >= c - 3; j--) {
            int sum = 1;
            for (int k = 0; k < 4; k++) {
                sum *= arr[i - k][j - k]; // Sum four adjacent numbers along the diagonal
            }
            if (sum > mixD3) {
                mixD3 = sum; // Update maxSum if a larger sum is found
            }
        }
    }
    printf("maximum along  diagonal 3 is %d\n", mixD3);
    if(mixD3>mixAll){ 
        mixAll=mixD3;
        direction=4;
    }
    // 
    	 for (int i = r-1; i > r - 3; i--) {
        for (int j = 0; j < c - 3; j++) {
            int sum = 1;
            for (int k = 0; k < 4; k++) {
                sum *= arr[i - k][j + k]; // Sum four adjacent numbers along the diagonal
            }
            if (sum > mixD4) {
                mixD4 = sum; // Update maxSum if a larger sum is found
            }
        }
    }
    printf("maximum along  diagonal 4 is %d\n", mixD4); 
    if(mixD4>mixAll){ 
        mixAll=mixD4;
        direction=4;
    }
    printf("\n\nMazimum of all is %d\n", mixAll);
    if(direction==1) printf("In Direction of Horizontal");
    if(direction==2) printf("In Direction of virtical");
    if(direction==3) printf("In Direction of diagonal");
    if(direction==4) printf("In Direction of anti diagonal");
    return 0;
}
